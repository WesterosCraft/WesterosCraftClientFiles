# WesterosCraft Resource Pack Repository #

NOTICE: This repository is officially obsolete (as of 2017-05-27) - All future updates will be done in our new repository,
https://gitlab.com/westeroscraft/westeroscraftrp